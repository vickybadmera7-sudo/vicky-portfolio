# Vicky Badmera Portfolio — Android publishing guide

Files:
- index.html — your portfolio website
- vicky-photo.png — your profile photograph

## Publish using GitHub + Vercel from Android
1. Sign in to GitHub in Chrome and open https://github.com/new
2. Create a public repository named `vicky-portfolio`.
3. Open the repository and choose Add file → Upload files.
4. Upload BOTH `index.html` and `vicky-photo.png` together, then commit the changes.
5. Visit https://vercel.com and sign in with GitHub.
6. Choose Add New → Project, import `vicky-portfolio`.
7. For a plain HTML website, choose framework preset `Other`; leave build command and output directory blank if the form allows it.
8. Deploy and open the generated URL on your phone.

Before submitting:
- Review all project descriptions and links for accuracy.
- Add a public contact email if you want one shown.
- Confirm the exact NASSCOM programme title and dates if you want those listed.
- Check the site on mobile and test all links.

Your website links:
GitHub: https://github.com/vickybadmera7-sudo
LinkedIn: https://www.linkedin.com/in/vicky-badmera-9802aa383/

Never share passwords or verification codes.
